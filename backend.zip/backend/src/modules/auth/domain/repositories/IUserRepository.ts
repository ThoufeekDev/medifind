import {User} from "../entities/User";
import { CreateUserData } from "../entities/User";

export interface IUserRepository{
    create(user:CreateUserData):Promise<User>;

    findByEmail(email:string):Promise<User | null>

    verifyUser(userId:string):Promise<void>

    findById(id:string):Promise<User | null>
}

// export interface CreateUserData {
//     name:string;
//     email:string;
//     password:string;
//     role?:Role,
// }

